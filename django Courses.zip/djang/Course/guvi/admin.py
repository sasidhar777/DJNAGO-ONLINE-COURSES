from django.contrib import admin
from guvi.models import Courses
# Register your models here.

class CourseAdmin(admin.ModelAdmin):
    list_display = ['cname' , 'author']

admin.site.register(Courses,CourseAdmin)
