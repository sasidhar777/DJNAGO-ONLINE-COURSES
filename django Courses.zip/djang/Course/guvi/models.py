from django.db import models

# Create your models here.

class Courses(models.Model):
    price = models.DecimalField(max_length=100,default=0,decimal_places=3,max_digits=5)
    cname = models.CharField(max_length=40)
    author = models.CharField(max_length=50)
    duration = models.TimeField()
    stcount = models.IntegerField()

    def __str__ (self):
         return self.cname

class Meta:
    abstract = True